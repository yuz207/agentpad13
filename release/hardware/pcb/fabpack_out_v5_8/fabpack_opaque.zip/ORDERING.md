# agentpad13 — How to order from PCBWay (stranger-ready)

*Applies to the packaged **v5_8** board (JS1 + RE1 = machine-placed THT top-side).*

This is the ordering runbook for the fab package produced by `build_fabpack.py`.
You do **not** need to understand PCB design to follow it. Everything you upload is
in the `<outdir>` the build wrote (e.g. `fabpack/out/`). Money / identity / uploads
are **your** decisions — this doc tells you exactly which file goes where and which
options to pick.

> Owner standard: *"a literal set of gerbers and drill files I can send to PCBWay and
> get the product to which I can solder a few final parts and be finished."* That set
> is `gerbers_<board>.zip` (bare board) + the per-SKU CPL/BOM in `assembly/`.

---

## 0. What's in the package

```
<outdir>/
  gerbers/                         the bare-board manufacturing files (9 Gerbers + drill)
  gerbers_<board>.zip              << UPLOAD THIS to the PCB (bare board) quote
  assembly/
    cpl_opaque.csv                 pick-and-place, opaque SKU      (91 parts placed)
    cpl_translucent.csv            pick-and-place, translucent SKU (111 parts placed)
    bom_opaque.csv                 BOM, opaque SKU                 << UPLOAD for assembly
    bom_translucent.csv            BOM, translucent SKU            << UPLOAD for assembly
    hand_solder_afterlist.csv      optional user touch contact; sockets/tacts opt-out only
  fabpack_opaque.zip               everything for the opaque SKU in one zip (archival)
  fabpack_translucent.zip          everything for the translucent SKU in one zip
  build_report.txt                 the numbers (read the PCBWAY TIER HINT line!)
  build_manifest.json              machine-readable record of every count/choice
```

**The bare PCB is identical for both SKUs.** Only the assembly (which parts get
placed) differs. So you order **one** bare board and choose **one** SKU's assembly.

---

## 1. Pick your SKU (variant)

| SKU | What it is | Underglow (side LEDs LED15-24 + caps C40-49) |
|---|---|---|
| **opaque** (Rev A default) | solid/opaque top shell | **not populated** (DNP) — you don't pay to place them |
| **translucent** | glowing diffuser top shell | **populated** — the shell glows from the edge LEDs |

The 14 top LEDs (LED1-14), all the per-key sockets, the MCU and power parts are the
**same in both**. Pick opaque unless you specifically built the translucent diffuser
shell. Use that SKU's `cpl_*.csv` and `bom_*.csv` everywhere below.

---

## 2. Order the bare PCB (PCB quote page)

Go to PCBWay → **PCB Instant Quote**. Upload **`gerbers_<board>.zip`**. Set:

| Option | Value | Why |
|---|---|---|
| Board type | Single pieces (not panel) | one design |
| Layers | **2** | 2-layer board |
| Dimensions | auto-detected ≈ **84.2 × 100.0 mm** | octagon; long axis is exactly 100 mm |
| Board thickness | **1.6 mm** | standard; matches the case |
| Material | **FR-4** (TG130 or TG155 both fine) | standard |
| Surface finish | **ENIG (recommended)** — HASL-LF is the cheaper fallback | ENIG reflows the 0.4 mm-pitch QFN-56 (RP2040) more reliably and reads premium gold-on-black; see DESIGN-DECISIONS C-ENIG |
| Solder mask | **Matte black** (glossy black is the cheaper fallback) | product deck aesthetic |
| Silkscreen | **White** | contrast on black |
| Copper weight | **1 oz** | default |
| Min hole / track | leave default, but **read the tier note in §2a** | the board uses 0.20 mm via drills |
| Gold fingers / impedance / castellated | **No** | not used |

**Fiducials:** the board carries 3 global fiducials (FID1-3) for the assembly
machine — nothing for you to configure; the fab reads them from the Gerbers.

**LED cut-outs are intentional:** the Edge.Cuts layer contains 14 small internal
rounded-rectangle cut-outs (one per top LED, LED1-14). These are **deliberate
light-path windows** for the reverse-mounted LEDs to shine through the board — do
**not** report them as an outline error if PCBWay's DFM flags "internal cutouts."

### 2a. Standard vs Advanced capability tier — pick by the build report

Open `build_report.txt` and find the **`PCBWAY TIER HINT`** line. It reports the
finished board's minimum copper track and minimum via drill, and tells you which
variant applies:

- **Variant A — standard capability** (finished board min track/space **≥ 0.152 mm /
  6 mil**): PCBWay's *standard* process covers 6/6 mil trace/space. Choose the normal
  (non-advanced) service. **Caveat:** this board's vias are **0.20 mm drill**. 0.30 mm
  is PCBWay's classic standard-tier minimum drill; **0.20 mm sits at the standard↔
  advanced boundary** and may add a small drill upcharge or nudge the order to the
  advanced tier — confirm on the live quote (it will tell you if the hole size bumps
  the price).
- **Variant B — advanced capability** (finished board has **any feature < 0.152 mm**,
  e.g. the documented 0.127 mm / 5-mil fallback route): choose PCBWay's **advanced
  PCB** capability (down to 3.5/3.5 mil). Expect a **small premium and +1–2 days**.

The packaged **v5_8 routed board** reports min track **0.152 mm**, min via **0.20 mm** →
Variant A (standard trace/space; confirm the 0.20 mm drill on the quote). This is the
final routed board (its build report shows **0 unconnected**); if you ever re-run the
build on a revised board, re-read the hint — these numbers regenerate from whichever
board you point it at.

---

## 3. Order assembly (turnkey / consigned — PCB Assembly page)

On the assembly page, choose **Turnkey** (PCBWay sources all parts by MPN — there is
no LCSC-only "basic/extended" caste to worry about). Then:

| Upload / setting | File / value |
|---|---|
| Assembly side | **Both sides** — bottom-side SMD reflow (every reflow part is on B.Cu) plus **two top-side parts**: JS1 and RE1 |
| Through-hole assembly | **Yes — 2 THT parts, machine-placed**: JS1, the YTL YA13 joystick (LCSC **C37323742**), and RE1, the Bourns encoder (LCSC **C143790**), both top-side / F.Cu |
| Number of unique parts | see `bom_<sku>.csv` (30 lines; DNP lines are flagged) |
| Placements | **opaque 91** / **translucent 111** (matches `cpl_<sku>.csv` rows) |
| BOM file | **`assembly/bom_<sku>.csv`** |
| Pick-and-place (CPL) file | **`assembly/cpl_<sku>.csv`** |
| DNP handling | the BOM's `Populate` column marks **DNP** rows — do NOT place them |

**CPL coordinate convention (so PCBWay's viewer lines up):** the CPL is the standard
KiCad export — millimetres, absolute (board) origin, rotation in degrees CCW, and the
`PosY` values are negative. Every SMD row is `Side = bottom`; the two exceptions are
**JS1 and RE1**, the two top-side THT controls, which are `Side = top` (this is normal KiCad output
that PCBWay/JLCPCB both accept). If PCBWay's DFM says bottom parts look mirrored, the
one-switch fix is to re-export with X mirrored — but do **not** pre-apply it; let
their DFM tell you. PCBWay's engineers confirm every placement/rotation during DFM
review before they build.

**DNP / do-not-populate for the SKU you picked** (already handled in the files):
- opaque: LED15-24, C40-49 (underglow), plus D1, C25, J2.
- translucent: D1, C25, J2 only.

---

## 4. Optional user-soldered touch contact (`hand_solder_afterlist.csv`)

There is no required hand-soldered board component. PCBWay places both JS1 and RE1.
The touch contact is deliberately user-selected and optional:

| Ref | Part | Buy | Notes |
|---|---|---|---|
| **TP5 contact** | Builder-supplied conductive spring, wire, or other contact | User-selected | Solder only if coupling TP5 to an electrode-equipped top plate. Omit for the blank/non-touch plate. This accessory never enters PCBWay's turnkey BOM or CPL. |

**Optional (only if you opt OUT of fab assembly for them):** the 13 hot-swap sockets
(SW1-13) and the 2 tact switches (SW14/15) are **fab-placed in the baseline** and are
already in the CPL. `hand_solder_afterlist.csv` lists them too, marked *"only if you
opt out of fab assembly for these"* — hand-soldering the 13 sockets instead saves
about **$2/board** but costs ~1 hour of back-side hand work per 5 boards. The owner
chose fab-placed; leave them in the CPL unless you deliberately remove them.

---

## 5. Price ballpark (estimates — prices move, get the live quote)

From the last complete `COST-ANALYSIS.md` model (v5_6 inputs; **no live quote was
captured**). v5_8 adds factory placement/procurement of the existing RE1, so treat
these as historical ballparks until PCBWay returns the mixed-assembly quote:

| | Opaque (Rev A default) | Translucent |
|---|---|---|
| PCBWay charge, fab + assembly + parts, **qty 5** | ~$160–190 for 5 boards (~$33–37/board; HASL→ENIG) | ~$185–215 for 5 (~$37–43/board) |
| **Historical full built-unit model, qty 5** | **~$78.22** | **~$82.68** |
| Historical full built-unit model, qty 10 | ~$69.51 | ~$73.98 |
| Reference: Creator Micro 2 Base | **$144** | $144 |

The open price inputs are the actual mixed-THT/RE1 factory charge, matte-black
upcharge, finish choice and US import tariff. Use PCBWay's returned quote, not this
historical model, as the purchase authority.

> Board-size note: the current board is **84.2 × 100.0 mm** (verified from Edge.Cuts).
> The long axis is **exactly 100 mm**, but the `.gbrjob` includes edge-stroke width and
> reports 100.100 mm. Confirm promo-tier treatment in the live quote; matte-black and
> ENIG may make the promo irrelevant regardless.

---

## 6. Pre-order gates (do these before you pay)

1. **Open the board in native KiCad 9 and run DRC** (expect 0 errors, 0 unconnected) —
   the packaged **v5_8** board is the final routed board; its build report shows **0
   unconnected** nets — confirm the same in KiCad before you pay.
2. **Joystick (JS1) is machine-placed — no early order or pinout metering needed.** JS1
   is the YTL YA13 (LCSC **C37323742**), placed by the fab as a top-side THT part. The
   only residual first-power-on check is the **axis-direction polarity note**
   (`firmware/POLARITY-NOTE.md` in the release): if the stick drives the cursor / arrows
   / scroll the **opposite** way from what you push, it is a **one-line firmware config**
   flip per reversed axis — no rebuild ships in this bundle.
3. Use PCBWay's **free DFM review** — let their engineers confirm the 0.20 mm vias,
   matte-black, ENIG, and the mixed assembly (**bottom-side SMD + top-side JS1/RE1
   through-hole**) before building.
4. Optional but cheap insurance: print the Gerbers **1:1 on paper** and drop your real
   parts on the pads to sanity-check footprints.

---

## 7. Option choices baked into this package (+ alternatives)

These were chosen for widest PCBWay compatibility. If PCBWay ever objects, here are
the documented alternatives (all re-selectable by editing the flags in
`build_fabpack.py`):

| Choice | Used | Alternative |
|---|---|---|
| Gerber filename style | **Protel extensions** (`.gtl/.gbl/.gts/...`) + `.gbrjob` | KiCad-native `.gbr` names (`--no-protel-ext`) — also accepted |
| Gerber format | **RS-274X, X2 attributes on, precision 6** | `--no-x2` for plain 274X if a legacy loader chokes |
| Drill format | **Excellon, mm, decimal zeros, absolute origin** | leading-zero-suppressed 2:4 / 3:3 (`--excellon-zeros-format suppressleading`) |
| Drill PTH/NPTH | **separate files** (`-PTH.drl`, `-NPTH.drl`) | merged single file (drop `--excellon-separate-th`) |
| CPL bottom-side X | **not negated** (standard KiCad CPL) | `--bottom-negate-x` if PCBWay DFM reports mirroring |
| Origin (all files) | **absolute / sheet origin** (one shared frame) | drill/place-file origin (`--use-drill-file-origin`) if you set an aux origin |

---

*Generated to accompany `build_fabpack.py` output. Re-run the build on the final
routed board and re-read this doc — the file names, counts, and the tier hint all
regenerate from whichever board you point it at.*

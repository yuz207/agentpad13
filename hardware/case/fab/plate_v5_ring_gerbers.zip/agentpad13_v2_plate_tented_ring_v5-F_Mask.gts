%TF.GenerationSoftware,KiCad,Pcbnew,9.0.9*%
%TF.CreationDate,2026-08-19T19:23:04-07:00*%
%TF.ProjectId,agentpad13_v2_plate_tented_ring_v5,6167656e-7470-4616-9431-335f76325f70,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.9) date 2026-08-19 19:23:04*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*

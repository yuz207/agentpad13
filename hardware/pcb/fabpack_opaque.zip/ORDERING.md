# agentpad13 - How to order from PCBWay

This is the ordering runbook for the fabrication package. You do **not** need to
understand PCB design to follow it. Everything you upload is in this package.

> Goal: a literal set of Gerbers and drill files you can send to PCBWay, plus the
> per-SKU CPL/BOM for assembly, then solder a few final parts and be finished.

---

## 0. What's in this package

```
gerbers/                     the bare-board manufacturing files (9 Gerbers + drill)
assembly/
  cpl_opaque.csv             pick-and-place, opaque SKU      (89 parts placed)
  cpl_translucent.csv        pick-and-place, translucent SKU (109 parts placed)
  bom_opaque.csv             BOM, opaque SKU                 << UPLOAD for assembly
  bom_translucent.csv        BOM, translucent SKU            << UPLOAD for assembly
  hand_solder_afterlist.csv  the parts YOU solder after the board arrives
ORDERING.md                  this file
```

The repository also ships `gerbers.zip` (the `gerbers/` folder above, zipped) at
`hardware/pcb/` - that is the file you upload to the bare-board quote.

**The bare PCB is identical for both SKUs.** Only the assembly (which parts get
placed) differs. So you order **one** bare board and choose **one** SKU's assembly.

---

## 1. Pick your SKU (variant)

| SKU | What it is | Underglow (side LEDs LED15-24 + caps C40-49) |
|---|---|---|
| **opaque** (Rev A default) | solid/opaque top shell | **not populated** (DNP) - you don't pay to place them |
| **translucent** | glowing diffuser top shell | **populated** - the shell glows from the edge LEDs |

The 14 top LEDs (LED1-14), all the per-key sockets, the MCU and power parts are the
**same in both**. Pick opaque unless you specifically built the translucent diffuser
shell. Use that SKU's `cpl_*.csv` and `bom_*.csv` everywhere below.

---

## 2. Order the bare PCB (PCB quote page)

Go to PCBWay -> **PCB Instant Quote**. Upload **`gerbers.zip`** (or this package's
`gerbers/` folder, zipped). Set:

| Option | Value | Why |
|---|---|---|
| Board type | Single pieces (not panel) | one design |
| Layers | **2** | 2-layer board |
| Dimensions | auto-detected ~= **84.2 x 100.0 mm** | long axis is exactly 100 mm |
| Board thickness | **1.6 mm** | standard; matches the case |
| Material | **FR-4** (TG130 or TG155 both fine) | standard |
| Surface finish | **ENIG (recommended)** - HASL-LF is the cheaper fallback | ENIG reflows the 0.4 mm-pitch QFN-56 (RP2040) more reliably and reads premium gold-on-black |
| Solder mask | **Matte black** (glossy black is the cheaper fallback) | aesthetic |
| Silkscreen | **White** | contrast on black |
| Copper weight | **1 oz** | default |
| Min hole / track | leave default, but **read the tier note in section 2a** | the board uses 0.20 mm via drills |
| Gold fingers / impedance / castellated | **No** | not used |

**Fiducials:** the board carries 3 global fiducials (FID1-3) for the assembly
machine - nothing for you to configure; the fab reads them from the Gerbers.

**LED cut-outs are intentional:** the Edge.Cuts layer contains 14 small internal
rounded-rectangle cut-outs (one per top LED, LED1-14). These are **deliberate
light-path windows** for the reverse-mounted LEDs to shine through the board - do
**not** report them as an outline error if PCBWay's DFM flags "internal cutouts."

### 2a. Standard vs Advanced capability tier

This board's finished minimums are **min track 0.152 mm (6 mil)** and **min via
0.20 mm drill**.

- **Trace/space** at 0.152 mm / 6 mil is covered by PCBWay's *standard* process
  (6/6 mil). Choose the normal (non-advanced) service.
- **Caveat - via drill:** 0.30 mm is PCBWay's classic standard-tier minimum drill;
  **0.20 mm sits at the standard<->advanced boundary** and may add a small drill
  upcharge or nudge the order to the advanced tier - confirm on the live quote (it
  will tell you if the hole size bumps the price).

---

## 3. Order assembly (turnkey / consigned - PCB Assembly page)

On the assembly page, choose **Turnkey** (PCBWay sources all parts by MPN). Then:

| Upload / setting | File / value |
|---|---|
| Assembly side | **Bottom only** (all SMD reflow parts are on the bottom / B.Cu) |
| Number of unique parts | see `bom_<sku>.csv` (28 lines; DNP lines are flagged) |
| Placements | **opaque 89** / **translucent 109** (matches `cpl_<sku>.csv` rows) |
| BOM file | **`assembly/bom_<sku>.csv`** |
| Pick-and-place (CPL) file | **`assembly/cpl_<sku>.csv`** |
| DNP handling | the BOM's `Populate` column marks **DNP** rows - do NOT place them |

**CPL coordinate convention (so PCBWay's viewer lines up):** the CPL is the standard
KiCad export - millimetres, absolute (board) origin, rotation in degrees CCW, and the
`PosY` values are negative with `Side = bottom` (normal KiCad output that PCBWay and
JLCPCB both accept). If PCBWay's DFM says bottom parts look mirrored, the one-switch
fix is to re-export with X mirrored - but do **not** pre-apply it; let their DFM tell
you. PCBWay's engineers confirm every placement/rotation during DFM review.

**DNP / do-not-populate for the SKU you picked** (already handled in the files):
- opaque: LED15-24, C40-49 (underglow), plus D1, C25, J2.
- translucent: D1, C25, J2 only.

---

## 4. Parts YOU hand-solder after the boards arrive (`hand_solder_afterlist.csv`)

These are **not** fab-placed. Do them with an iron once the assembled boards land:

| Ref | Part | Buy | Notes |
|---|---|---|---|
| **JS1** | Adafruit 3103 2-axis PSP slider joystick | DigiKey **6193574** / Adafruit, **$4.95** | **METER THE PINOUT FIRST.** The Vcc/X/Y/GND order on the 4 pads is TBD until metered - put a meter on a physical 3103 and confirm which pad is which **before** soldering (this matches the board silkscreen note). Firmware keeps the joystick ADC pins swappable so a surprise is a one-line fix. Order the genuine Adafruit part - clones are not qualified. |
| **RE1** | EC11 rotary encoder + push (PEC11R-4215F-S0024) | LCSC **C143790** (low stock - buy early) / DigiKey **4499665**, **$2.36** | Through-hole plugin; hand-soldered to avoid PCBWay's through-hole assembly fee tier. |

**Optional (only if you opt OUT of fab assembly for them):** the 13 hot-swap sockets
(SW1-13) and the 2 tact switches (SW14/15) are **fab-placed by default** and are
already in the CPL. `hand_solder_afterlist.csv` lists them too, marked *"only if you
opt out of fab assembly for these"* - hand-soldering the 13 sockets instead saves a
little per board but costs about an hour of back-side hand work per 5 boards. The
default is fab-placed; leave them in the CPL unless you deliberately remove them.

---

## 5. Price ballpark (estimates - prices move, get the live quote)

Component prices are live as of 2026-07-15; fab/assembly are computed estimates
anchored to PCBWay's published pricing - **no live quote was captured**, so treat as
ballpark.

| | Opaque (Rev A default) | Translucent |
|---|---|---|
| PCBWay charge, fab + assembly + parts, **qty 5** | ~$160-190 for 5 boards (~$33-37/board; HASL->ENIG) | ~$185-215 for 5 (~$37-43/board) |
| **Full built-unit cost** incl. hand parts + case/keycaps, **qty 5** | **~$82** | **~$86** |
| Full built-unit, qty 10 | ~$73 | ~$78 |
| Reference: Work Louder Creator Micro 2 Base | **$144** | $144 |

Every scenario lands well under the $144 reference. Two figures most likely to move
at order time: the **matte-black upcharge** (~+$15/order) and **US import tariff**
(volatile - budget separately).

---

## 6. Pre-order gates (do these before you pay)

1. **Open the board in native KiCad 9 and run DRC.** The released board
   (`hardware/pcb/agentpad13/agentpad13.kicad_pcb`) is **DRC-clean: 0 violations,
   0 unconnected**. Re-run it yourself to confirm before committing.
2. **Order the Adafruit 3103 early and meter its pinout** (section 4) - this is the
   single biggest unvalidated item; do it before you commit the design.
3. Use PCBWay's **free DFM review** - let their engineers confirm the 0.20 mm vias,
   matte-black, ENIG, and the bottom-side single-pass assembly before building.
4. Optional but cheap insurance: print the Gerbers **1:1 on paper** and drop your
   real parts on the pads to sanity-check footprints.

---

## 7. Option choices baked into this package (+ alternatives)

These were chosen for widest PCBWay compatibility. If PCBWay ever objects, the
documented alternatives are:

| Choice | Used | Alternative |
|---|---|---|
| Gerber filename style | **Protel extensions** (`.gtl/.gbl/.gts/...`) + `.gbrjob` | KiCad-native `.gbr` names - also accepted |
| Gerber format | **RS-274X, X2 attributes on, precision 6** | plain 274X if a legacy loader chokes |
| Drill format | **Excellon, mm, decimal zeros, absolute origin** | leading-zero-suppressed 2:4 / 3:3 |
| Drill PTH/NPTH | **separate files** (`-PTH.drl`, `-NPTH.drl`) | merged single file |
| CPL bottom-side X | **not negated** (standard KiCad CPL) | negate X if PCBWay DFM reports mirroring |
| Origin (all files) | **absolute / sheet origin** (one shared frame) | drill/place-file origin if you set an aux origin |
